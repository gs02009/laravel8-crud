

<!--
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css>




<?php $__env->stopSection(); ?>

-->

<?php $__env->startSection('contenido'); ?>

<h1> Sistema de Registros</h1>




<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal-nuevo">
  Nuevo Registro
</button>


<div class="container p-5">

<table id="TABLA" class="table table-striped table-hover tabla-dark table-bordered">
        <thead>
            <tr>
                <th>id</th>
                <th>Propietario</th>
                <th>Tipo Placa</th>
                <th>No. Placa</th>
                <th>Marca</th>
                <th>Operaciones</th>

            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td> <?php echo e($vehiculo->ID); ?></td>
                <td><?php echo e($vehiculo->PROPIETARIO); ?></td>
                <td><?php echo e($vehiculo->IDPLACAS); ?></td>
                <td><?php echo e($vehiculo->NUMPLACA); ?></td>
                <td><?php echo e($vehiculo->MARCA); ?></td>
                <td>

          
        
          

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal-editar">
  Editar
</button>

          
           
            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($vehiculo->ID); ?>">
  Eliminar
</button>
<!-- Button trigger modal -->
<button type="button" class="btn btn-dark btn-sm" data-bs-toggle="modal" data-bs-target="#modal-show-<?php echo e($vehiculo->ID); ?>">
  Ver
</button>
    


        </td>

            </tr>
            <?php echo $__env->make('vehiculo.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('vehiculo.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('vehiculo.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </tbody>
        <tfoot>
            <tr>

            </tr>
        </tfoot>
    </table>

</div>


<?php echo $__env->make('vehiculo.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MARIKLE\Desktop\proyecto\proyecto\resources\views/vehiculo/index.blade.php ENDPATH**/ ?>