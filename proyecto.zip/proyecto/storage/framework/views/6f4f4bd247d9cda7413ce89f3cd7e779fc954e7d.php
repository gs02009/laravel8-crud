


<!-- Modal -->
<div class="modal fade" id="modal-show-<?php echo e($vehiculo->ID); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ver Registros</h5>
    
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      
    <form action="/vehiculos/<?php echo e($vehiculo->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

<div class="mb-3">
    <label for=""class="form-label">Propietario:</label>
    <input type="text" disabled name="propietario" block class="form-control" id="propietario" tabindex="2" value="<?php echo e($vehiculo->PROPIETARIO); ?>">    
</div>
<div class="mb-3">

<label for=""class="form-label">Tipo de Placa:</label>


<select name="idplacas" id="idplacas" disabled>
    <?php $__currentLoopData = $placas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($placa->ID); ?>" 
        <?php
   
    if($placa->ID == $vehiculo->IDPLACAS) {
	echo('selected');
}
?>
        
        >
            <?php echo e($placa->NOMPLACA); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

</div>

<div class="mb-3">
    <label for=""class="form-label">Número de la Placa:</label>
    <input type="text" name="numplaca" disabled class="form-control" id="numplaca" tabindex="3" max="6" value="<?php echo e($vehiculo->NUMPLACA); ?>">    
</div>
<div class="mb-3">
    <label for=""class="form-label">Marca:</label>
    <input type="text" name="marca" disabled class="form-control" id="marca" tabindex="4" value="<?php echo e($vehiculo->MARCA); ?>">    
</div>


</form>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>









<?php /**PATH C:\Users\MARIKLE\Desktop\proyecto\proyecto\resources\views/vehiculo/show.blade.php ENDPATH**/ ?>